/* ============================================================
   ReBuildAI — Application Logic, Data & AI Matching Engine
   ============================================================ */

// ── State ──
let currentRole = 'buyer';
let currentPage = 'landing';
let uploadedPhotos = [];

// ── Material Icons Map ──
const materialIcons = {
  'TMT Steel Bars': 'fas fa-bars',
  'Portland Cement': 'fas fa-cubes',
  'Red Bricks': 'fas fa-cube',
  'AAC Blocks': 'fas fa-square',
  'Plywood Sheets': 'fas fa-layer-group',
  'Sand': 'fas fa-mountain-sun',
  'Gravel/Aggregate': 'fas fa-circle-nodes',
  'Timber': 'fas fa-tree',
  'Roofing Sheets': 'fas fa-house-chimney',
  'Glass Panels': 'fas fa-window-maximize',
  'Pipes (PVC/GI)': 'fas fa-pipe-section',
  'Electrical Conduits': 'fas fa-bolt',
  'Tiles': 'fas fa-border-all',
  'Scaffolding': 'fas fa-tower-broadcast',
};

// ── City Coordinates (for distance calc) ──
const cityCoords = {
  Mumbai: { lat: 19.076, lng: 72.877 },
  Delhi: { lat: 28.704, lng: 77.102 },
  Bangalore: { lat: 12.972, lng: 77.594 },
  Chennai: { lat: 13.083, lng: 80.270 },
  Hyderabad: { lat: 17.385, lng: 78.487 },
  Pune: { lat: 18.520, lng: 73.856 },
  Ahmedabad: { lat: 23.023, lng: 72.571 },
  Kolkata: { lat: 22.572, lng: 88.364 },
  Jaipur: { lat: 26.912, lng: 75.787 },
  Lucknow: { lat: 26.847, lng: 80.947 },
};

// ── New Material Prices (₹ per unit) — market estimates ──
const newPrices = {
  'TMT Steel Bars': 65000,    // per ton
  'Portland Cement': 380,     // per bag
  'Red Bricks': 9,            // per piece
  'AAC Blocks': 55,           // per piece
  'Plywood Sheets': 95,       // per sqft
  'Sand': 2800,               // per cu.m
  'Gravel/Aggregate': 1800,   // per cu.m
  'Timber': 2200,             // per cu.ft
  'Roofing Sheets': 450,      // per sqft
  'Glass Panels': 220,        // per sqft
  'Pipes (PVC/GI)': 180,      // per piece
  'Electrical Conduits': 85,  // per piece
  'Tiles': 65,                // per sqft
  'Scaffolding': 12000,       // per set
};

// ── CO₂ Emission Factors (kg CO₂ per kg of material) ──
const co2Factors = {
  'TMT Steel Bars': 1.85,
  'Portland Cement': 0.9,
  'Red Bricks': 0.24,
  'AAC Blocks': 0.18,
  'Plywood Sheets': 0.46,
  'Sand': 0.005,
  'Gravel/Aggregate': 0.008,
  'Timber': 0.46,
  'Roofing Sheets': 2.1,
  'Glass Panels': 0.86,
  'Pipes (PVC/GI)': 2.5,
  'Electrical Conduits': 2.5,
  'Tiles': 0.74,
  'Scaffolding': 1.85,
};

// ── Condition Scores ──
const conditionScores = { Excellent: 1.0, Good: 0.8, Fair: 0.55, Salvage: 0.3 };
const conditionRank = { Excellent: 4, Good: 3, Fair: 2, Salvage: 1 };

// ── Sample Surplus Listings ──
let surplusListings = [
  {
    id: 1,
    type: 'TMT Steel Bars',
    qty: 500,
    unit: 'kg',
    condition: 'Good',
    location: 'Mumbai',
    price: 48000,
    priceUnit: 'per ton',
    date: '2026-09-20',
    supplier: 'Rajesh Sharma',
    company: 'Sharma Constructions Pvt. Ltd.',
    desc: 'Fe 500D grade TMT bars from completed highway project. Stored in covered warehouse. Mill test certificates available.',
  },
  {
    id: 2,
    type: 'Portland Cement',
    qty: 200,
    unit: 'bags',
    condition: 'Excellent',
    location: 'Pune',
    price: 290,
    priceUnit: 'per bag',
    date: '2026-09-18',
    supplier: 'Arjun Desai',
    company: 'Desai Infrastructure',
    desc: 'OPC 53 Grade cement. Sealed bags, manufactured Aug 2026. Excess from commercial complex project.',
  },
  {
    id: 3,
    type: 'Red Bricks',
    qty: 10000,
    unit: 'pieces',
    condition: 'Good',
    location: 'Delhi',
    price: 6.5,
    priceUnit: 'per piece',
    date: '2026-09-22',
    supplier: 'Vikram Singh',
    company: 'Singh Builders',
    desc: 'First class red bricks. Uniform size, good compressive strength. From demolished heritage site — carefully extracted.',
  },
  {
    id: 4,
    type: 'Plywood Sheets',
    qty: 300,
    unit: 'sqft',
    condition: 'Good',
    location: 'Bangalore',
    price: 68,
    priceUnit: 'per sqft',
    date: '2026-09-25',
    supplier: 'Meena Krishnan',
    company: 'MK Interiors',
    desc: '19mm BWR grade plywood. Used for formwork — cleaned and in good shape. Slight surface marks but structurally sound.',
  },
  {
    id: 5,
    type: 'TMT Steel Bars',
    qty: 2000,
    unit: 'kg',
    condition: 'Excellent',
    location: 'Chennai',
    price: 52000,
    priceUnit: 'per ton',
    date: '2026-09-19',
    supplier: 'Karthik Rajan',
    company: 'Rajan Steel Structures',
    desc: 'Unused 12mm and 16mm Fe 500D bars. Project cancelled — brand new stock. All documentation available.',
  },
  {
    id: 6,
    type: 'AAC Blocks',
    qty: 5000,
    unit: 'pieces',
    condition: 'Excellent',
    location: 'Hyderabad',
    price: 38,
    priceUnit: 'per piece',
    date: '2026-09-21',
    supplier: 'Priya Patel',
    company: 'Patel Development Corp.',
    desc: '600×200×200mm AAC blocks. Surplus from residential tower project. Stored in dry conditions.',
  },
  {
    id: 7,
    type: 'Scaffolding',
    qty: 50,
    unit: 'pieces',
    condition: 'Fair',
    location: 'Mumbai',
    price: 8500,
    priceUnit: 'per set',
    date: '2026-09-17',
    supplier: 'Raj Kumar',
    company: 'Kumar Rentals',
    desc: 'H-frame scaffolding sets. Used across 3 projects. Some surface rust but structurally certified. Includes braces and planks.',
  },
  {
    id: 8,
    type: 'Tiles',
    qty: 800,
    unit: 'sqft',
    condition: 'Excellent',
    location: 'Pune',
    price: 45,
    priceUnit: 'per sqft',
    date: '2026-09-23',
    supplier: 'Sneha Reddy',
    company: 'Reddy Tiles & Marble',
    desc: '600×600mm vitrified floor tiles, ivory shade. Sealed boxes, overordered for hotel lobby project.',
  },
  {
    id: 9,
    type: 'Sand',
    qty: 100,
    unit: 'cu.m',
    condition: 'Good',
    location: 'Ahmedabad',
    price: 2000,
    priceUnit: 'per cu.m',
    date: '2026-09-20',
    supplier: 'Amit Joshi',
    company: 'Joshi Aggregates',
    desc: 'Manufactured sand (M-sand), Zone II grading. Tested and certified. Available for immediate pickup.',
  },
  {
    id: 10,
    type: 'Portland Cement',
    qty: 500,
    unit: 'bags',
    condition: 'Good',
    location: 'Delhi',
    price: 310,
    priceUnit: 'per bag',
    date: '2026-09-26',
    supplier: 'Ravi Malhotra',
    company: 'Malhotra Civil Works',
    desc: 'PPC cement. Bags in good condition — some outer packaging slightly worn. Manufactured Jul 2026.',
  },
  {
    id: 11,
    type: 'TMT Steel Bars',
    qty: 800,
    unit: 'kg',
    condition: 'Fair',
    location: 'Kolkata',
    price: 42000,
    priceUnit: 'per ton',
    date: '2026-10-01',
    supplier: 'Sanjay Ghosh',
    company: 'Ghosh & Sons Engineering',
    desc: 'Mixed diameter TMT bars (8mm–20mm). Some light surface rust, needs cleaning. Stored outdoors.',
  },
  {
    id: 12,
    type: 'Glass Panels',
    qty: 150,
    unit: 'sqft',
    condition: 'Good',
    location: 'Bangalore',
    price: 165,
    priceUnit: 'per sqft',
    date: '2026-09-28',
    supplier: 'Deepa Nair',
    company: 'Nair Glazing Solutions',
    desc: 'Tempered 12mm glass panels. Removed from office renovation — no chips or cracks. Various sizes available.',
  },
];

// ── Sample Requests ──
let requests = [
  {
    id: 1,
    materialType: 'TMT Steel Bars',
    qty: '300 kg',
    from: 'Priya Patel',
    to: 'Rajesh Sharma',
    status: 'pending',
    date: '2026-09-14',
    listingId: 1,
  },
  {
    id: 2,
    materialType: 'Portland Cement',
    qty: '100 bags',
    from: 'Sneha Reddy',
    to: 'Arjun Desai',
    status: 'accepted',
    date: '2026-09-12',
    listingId: 2,
  },
  {
    id: 3,
    materialType: 'Red Bricks',
    qty: '5000 pieces',
    from: 'Amit Joshi',
    to: 'Vikram Singh',
    status: 'accepted',
    date: '2026-09-10',
    listingId: 3,
  },
  {
    id: 4,
    materialType: 'Glass Panels',
    qty: '80 sqft',
    from: 'Karthik Rajan',
    to: 'Deepa Nair',
    status: 'declined',
    date: '2026-09-08',
    listingId: 12,
  },
  {
    id: 5,
    materialType: 'Scaffolding',
    qty: '20 pieces',
    from: 'Ravi Malhotra',
    to: 'Raj Kumar',
    status: 'pending',
    date: '2026-09-13',
    listingId: 7,
  },
];

// ============================================================
//  NAVIGATION & ROLE MANAGEMENT
// ============================================================

function showPage(page) {
  currentPage = page;
  const landingPage = document.getElementById('page-landing');
  const appShell = document.getElementById('app-shell');

  if (page === 'landing') {
    landingPage.classList.add('active');
    landingPage.classList.remove('hidden');
    appShell.classList.add('hidden');
    document.body.style.overflow = '';
    return;
  }

  // Show app shell
  landingPage.classList.remove('active');
  landingPage.classList.add('hidden');
  appShell.classList.remove('hidden');

  // Hide all page-content sections
  document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));

  // Map page names to section IDs
  const pageMap = {
    dashboard: 'page-dashboard',
    'list-material': 'page-list-material',
    'find-material': 'page-find-material',
    'ai-matching': 'page-ai-matching',
    requests: 'page-requests',
    impact: 'page-impact',
    admin: 'page-admin',
  };

  const targetId = pageMap[page];
  if (targetId) {
    const el = document.getElementById(targetId);
    if (el) el.classList.remove('hidden');
  }

  // Update topbar title
  const titles = {
    dashboard: 'Dashboard',
    'list-material': 'List Surplus Material',
    'find-material': 'Find Materials',
    'ai-matching': 'AI Material Matching',
    requests: 'Requests',
    impact: 'Environmental Impact',
    admin: 'Admin Overview',
  };
  document.getElementById('topbar-title').textContent = titles[page] || 'Dashboard';

  // Update active sidebar link
  document.querySelectorAll('.sidebar-nav a').forEach(a => {
    a.classList.toggle('active', a.dataset.page === page);
  });

  // Render page-specific content
  if (page === 'dashboard') renderDashboard();
  if (page === 'list-material') renderMyListings();
  if (page === 'find-material') renderFindListings();
  if (page === 'requests') renderRequests();
  if (page === 'impact') renderImpactDashboard();
  if (page === 'admin') renderAdminDashboard();

  // Close sidebar on mobile
  document.getElementById('sidebar').classList.remove('open');

  // Scroll to top
  document.querySelector('.main-content').scrollTo(0, 0);
}

function switchRole(role) {
  currentRole = role;

  // Sync all role selectors
  document.getElementById('role-select').value = role;
  document.getElementById('sidebar-role-select').value = role;

  // Update sidebar info
  const names = { buyer: 'Priya Patel', supplier: 'Rajesh Sharma', admin: 'Admin User' };
  const icons = { buyer: 'fas fa-cart-shopping', supplier: 'fas fa-warehouse', admin: 'fas fa-shield-halved' };

  document.getElementById('sidebar-name').textContent = names[role];
  document.getElementById('sidebar-role-badge').textContent = role.charAt(0).toUpperCase() + role.slice(1);
  document.getElementById('sidebar-avatar').innerHTML = `<i class="${icons[role]}"></i>`;

  buildSidebarNav();

  // Navigate to dashboard for new role
  if (currentPage !== 'landing') showPage('dashboard');
}

function buildSidebarNav() {
  const nav = document.getElementById('sidebar-nav');
  let links = [];

  const commonLinks = [
    { page: 'dashboard', icon: 'fas fa-gauge-high', label: 'Dashboard' },
  ];

  if (currentRole === 'supplier') {
    links = [
      ...commonLinks,
      { page: 'list-material', icon: 'fas fa-plus-circle', label: 'List Surplus' },
      { page: 'requests', icon: 'fas fa-inbox', label: 'Requests' },
      { page: 'impact', icon: 'fas fa-leaf', label: 'Impact Dashboard' },
    ];
  } else if (currentRole === 'buyer') {
    links = [
      ...commonLinks,
      { page: 'find-material', icon: 'fas fa-search', label: 'Find Materials' },
      { page: 'ai-matching', icon: 'fas fa-brain', label: 'AI Matching' },
      { page: 'requests', icon: 'fas fa-inbox', label: 'My Requests' },
      { page: 'impact', icon: 'fas fa-leaf', label: 'Impact Dashboard' },
    ];
  } else if (currentRole === 'admin') {
    links = [
      ...commonLinks,
      { page: 'admin', icon: 'fas fa-shield-halved', label: 'Admin Overview' },
      { page: 'find-material', icon: 'fas fa-search', label: 'All Listings' },
      { page: 'requests', icon: 'fas fa-inbox', label: 'All Requests' },
      { page: 'impact', icon: 'fas fa-leaf', label: 'Impact Dashboard' },
    ];
  }

  nav.innerHTML = links.map(l =>
    `<a href="#" data-page="${l.page}" class="${l.page === currentPage ? 'active' : ''}" onclick="showPage('${l.page}'); return false;">
      <i class="${l.icon}"></i> ${l.label}
    </a>`
  ).join('');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function toggleMobileNav() {
  const links = document.getElementById('nav-links');
  links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
}

// ============================================================
//  DASHBOARD RENDERING
// ============================================================

function renderDashboard() {
  const greetEl = document.getElementById('dashboard-greeting');
  const descEl = document.getElementById('dashboard-desc');
  const statsEl = document.getElementById('dashboard-stats');
  const widgetsEl = document.getElementById('dashboard-widgets');

  if (currentRole === 'buyer') {
    greetEl.textContent = 'Welcome back, Priya!';
    descEl.textContent = 'Find the best surplus materials for your next project.';
    statsEl.innerHTML = `
      ${statCard('fas fa-search', 'emerald', 'Available Listings', surplusListings.length, '↑ 12 new this week')}
      ${statCard('fas fa-inbox', 'blue', 'Active Requests', requests.filter(r => r.status === 'pending').length, '')}
      ${statCard('fas fa-check-circle', 'purple', 'Completed', requests.filter(r => r.status === 'accepted').length, '₹2.4L saved')}
      ${statCard('fas fa-leaf', 'amber', 'CO₂ Avoided', '4.2 T', 'Demo estimate')}
    `;
    widgetsEl.innerHTML = `
      <div class="widget-card">
        <h3><i class="fas fa-clock"></i> Recent Listings</h3>
        <div class="table-responsive">
          <table class="data-table">
            <thead><tr><th>Material</th><th>Qty</th><th>Location</th><th>Condition</th><th>Price</th></tr></thead>
            <tbody>
              ${surplusListings.slice(0, 5).map(l => `
                <tr>
                  <td>${l.type}</td>
                  <td>${l.qty} ${l.unit}</td>
                  <td>${l.location}</td>
                  <td><span class="condition-${l.condition.toLowerCase()}" style="font-weight:600">${l.condition}</span></td>
                  <td>₹${l.price.toLocaleString('en-IN')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
      <div class="widget-card">
        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <button class="btn btn-primary" onclick="showPage('ai-matching')"><i class="fas fa-brain"></i> AI Match Materials</button>
          <button class="btn btn-outline" onclick="showPage('find-material')"><i class="fas fa-search"></i> Browse Listings</button>
          <button class="btn btn-outline" onclick="showPage('requests')"><i class="fas fa-inbox"></i> View Requests</button>
        </div>
      </div>
    `;
  } else if (currentRole === 'supplier') {
    greetEl.textContent = 'Welcome back, Rajesh!';
    descEl.textContent = 'Manage your surplus material listings.';
    const myListings = surplusListings.filter(l => l.supplier === 'Rajesh Sharma');
    statsEl.innerHTML = `
      ${statCard('fas fa-boxes-stacked', 'emerald', 'Active Listings', myListings.length, '')}
      ${statCard('fas fa-inbox', 'blue', 'Pending Requests', requests.filter(r => r.status === 'pending').length, '')}
      ${statCard('fas fa-check-circle', 'purple', 'Completed Deals', '8', '₹4.8L revenue')}
      ${statCard('fas fa-recycle', 'amber', 'Material Reused', '1.2 T', 'Demo estimate')}
    `;
    widgetsEl.innerHTML = `
      <div class="widget-card">
        <h3><i class="fas fa-inbox"></i> Recent Requests</h3>
        <div class="table-responsive">
          <table class="data-table">
            <thead><tr><th>Material</th><th>Quantity</th><th>From</th><th>Status</th></tr></thead>
            <tbody>
              ${requests.slice(0, 4).map(r => `
                <tr>
                  <td>${r.materialType}</td>
                  <td>${r.qty}</td>
                  <td>${r.from}</td>
                  <td><span class="request-status status-${r.status}-badge">${r.status}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
      <div class="widget-card">
        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <button class="btn btn-primary" onclick="showPage('list-material')"><i class="fas fa-plus"></i> List New Material</button>
          <button class="btn btn-outline" onclick="showPage('requests')"><i class="fas fa-inbox"></i> View Requests</button>
          <button class="btn btn-outline" onclick="showPage('impact')"><i class="fas fa-leaf"></i> Impact Dashboard</button>
        </div>
      </div>
    `;
  } else {
    greetEl.textContent = 'Admin Dashboard';
    descEl.textContent = 'Platform-wide overview and management.';
    statsEl.innerHTML = `
      ${statCard('fas fa-users', 'emerald', 'Total Users', '247', '↑ 18 this week')}
      ${statCard('fas fa-boxes-stacked', 'blue', 'Total Listings', surplusListings.length, '↑ 5 today')}
      ${statCard('fas fa-handshake', 'purple', 'Transactions', '340', '₹18.2Cr total')}
      ${statCard('fas fa-leaf', 'amber', 'CO₂ Saved', '890 T', 'Platform total')}
    `;
    widgetsEl.innerHTML = `
      <div class="widget-card">
        <h3><i class="fas fa-chart-line"></i> Platform Activity</h3>
        <div class="table-responsive">
          <table class="data-table">
            <thead><tr><th>Metric</th><th>Today</th><th>This Week</th><th>This Month</th></tr></thead>
            <tbody>
              <tr><td>New Listings</td><td>5</td><td>23</td><td>87</td></tr>
              <tr><td>Material Requests</td><td>8</td><td>42</td><td>156</td></tr>
              <tr><td>Completed Deals</td><td>3</td><td>15</td><td>64</td></tr>
              <tr><td>New Registrations</td><td>4</td><td>18</td><td>52</td></tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="widget-card">
        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <button class="btn btn-primary" onclick="showPage('admin')"><i class="fas fa-shield-halved"></i> Admin Panel</button>
          <button class="btn btn-outline" onclick="showPage('impact')"><i class="fas fa-leaf"></i> Impact Dashboard</button>
          <button class="btn btn-outline" onclick="showPage('requests')"><i class="fas fa-inbox"></i> All Requests</button>
        </div>
      </div>
    `;
  }
}

function statCard(icon, color, label, value, change) {
  return `
    <div class="stat-card">
      <div class="stat-icon ${color}"><i class="${icon}"></i></div>
      <div class="stat-info">
        <span class="stat-label">${label}</span>
        <span class="stat-value">${value}</span>
        ${change ? `<span class="stat-change">${change}</span>` : ''}
      </div>
    </div>
  `;
}

// ============================================================
//  LISTINGS
// ============================================================

function renderListingCard(listing, showRequest = false) {
  const icon = materialIcons[listing.type] || 'fas fa-box';
  const condClass = `condition-${listing.condition.toLowerCase()}`;

  return `
    <div class="listing-card">
      <div class="listing-image">
        <i class="${icon}"></i>
        <span class="listing-condition-badge ${condClass}">${listing.condition}</span>
      </div>
      <div class="listing-body">
        <h3>${listing.type}</h3>
        <div class="listing-meta">
          <div class="listing-meta-item"><i class="fas fa-cubes"></i> ${listing.qty.toLocaleString('en-IN')} ${listing.unit}</div>
          <div class="listing-meta-item"><i class="fas fa-location-dot"></i> ${listing.location}</div>
          <div class="listing-meta-item"><i class="fas fa-calendar"></i> Available: ${formatDate(listing.date)}</div>
          <div class="listing-meta-item"><i class="fas fa-user"></i> ${listing.supplier}</div>
        </div>
        <div class="listing-price">₹${listing.price.toLocaleString('en-IN')} <small>${listing.priceUnit}</small></div>
        <div class="listing-actions">
          ${showRequest ? `<button class="btn btn-primary btn-sm" onclick="openRequestModal(${listing.id})"><i class="fas fa-paper-plane"></i> Request</button>` : ''}
          <button class="btn btn-outline btn-sm" onclick="openDetailModal(${listing.id})"><i class="fas fa-eye"></i> Details</button>
        </div>
      </div>
    </div>
  `;
}

function renderMyListings() {
  const grid = document.getElementById('my-listings-grid');
  const myListings = surplusListings.filter(l => l.supplier === 'Rajesh Sharma');
  grid.innerHTML = myListings.length
    ? myListings.map(l => renderListingCard(l, false)).join('')
    : '<div class="empty-state-small"><i class="fas fa-boxes-stacked"></i><p>No listings yet. Add your first surplus material above!</p></div>';
}

function renderFindListings() {
  const grid = document.getElementById('find-listings-grid');
  const filtered = getFilteredListings();
  grid.innerHTML = filtered.length
    ? filtered.map(l => renderListingCard(l, currentRole === 'buyer')).join('')
    : '<div class="empty-state-small"><i class="fas fa-search"></i><p>No materials match your filters. Try adjusting your search.</p></div>';
}

function getFilteredListings() {
  const search = document.getElementById('search-input').value.toLowerCase();
  const typeFilter = document.getElementById('filter-type').value;
  const condFilter = document.getElementById('filter-condition').value;
  const locFilter = document.getElementById('filter-location').value;

  return surplusListings.filter(l => {
    if (search && !l.type.toLowerCase().includes(search) && !l.desc.toLowerCase().includes(search)) return false;
    if (typeFilter && l.type !== typeFilter) return false;
    if (condFilter && l.condition !== condFilter) return false;
    if (locFilter && l.location !== locFilter) return false;
    return true;
  });
}

function filterMaterials() {
  renderFindListings();
}

// ============================================================
//  LISTING FORM
// ============================================================

function handleListMaterial(e) {
  e.preventDefault();

  const newListing = {
    id: surplusListings.length + 1,
    type: document.getElementById('mat-type').value,
    qty: parseInt(document.getElementById('mat-qty').value),
    unit: document.getElementById('mat-unit').value,
    condition: document.getElementById('mat-condition').value,
    location: document.getElementById('mat-location').value,
    price: parseInt(document.getElementById('mat-price').value) || 0,
    priceUnit: `per ${document.getElementById('mat-unit').value}`,
    date: document.getElementById('mat-date').value,
    supplier: currentRole === 'supplier' ? 'Rajesh Sharma' : 'Demo User',
    company: 'Your Company',
    desc: document.getElementById('mat-desc').value || '',
  };

  surplusListings.unshift(newListing);
  showToast('Material listed successfully!', 'success');
  e.target.reset();
  document.getElementById('photo-preview-grid').innerHTML = '';
  uploadedPhotos = [];
  renderMyListings();
}

function handlePhotoUpload(e) {
  const files = Array.from(e.target.files);
  const grid = document.getElementById('photo-preview-grid');

  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = (ev) => {
      const id = Date.now() + Math.random();
      uploadedPhotos.push({ id, name: file.name });
      grid.innerHTML += `
        <div class="photo-preview-item" id="photo-${id}">
          <img src="${ev.target.result}" alt="${file.name}" />
          <button class="remove-photo" onclick="removePhoto('${id}')"><i class="fas fa-times"></i></button>
        </div>
      `;
    };
    reader.readAsDataURL(file);
  });
}

function removePhoto(id) {
  const el = document.getElementById(`photo-${id}`);
  if (el) el.remove();
  uploadedPhotos = uploadedPhotos.filter(p => p.id != id);
}

// ============================================================
//  AI MATERIAL MATCHING ENGINE
// ============================================================

function runAIMatching(e) {
  e.preventDefault();

  const requirements = {
    type: document.getElementById('ai-mat-type').value,
    qty: parseInt(document.getElementById('ai-qty').value),
    location: document.getElementById('ai-location').value,
    minCondition: document.getElementById('ai-condition').value,
    date: document.getElementById('ai-date').value,
  };

  const panel = document.getElementById('ai-results-panel');

  // Show loading
  panel.innerHTML = `
    <div class="ai-loading">
      <div class="spinner"></div>
      <p>Analysing ${surplusListings.length} surplus listings…</p>
      <p style="font-size:0.78rem;color:var(--text-muted);margin-top:8px;">Calculating match scores across 5 weighted criteria</p>
    </div>
  `;

  // Simulate processing delay
  setTimeout(() => {
    const matches = calculateMatches(requirements);
    renderMatchResults(matches, requirements);
  }, 1500);
}

function calculateMatches(req) {
  const scored = surplusListings.map(listing => {
    // 1. Material Compatibility (30%)
    let matScore = 0;
    if (listing.type === req.type) {
      matScore = 1.0;
    } else {
      // Partial match for related materials
      const related = {
        'TMT Steel Bars': ['Scaffolding'],
        'Portland Cement': ['AAC Blocks'],
        'Red Bricks': ['AAC Blocks'],
        'AAC Blocks': ['Red Bricks'],
      };
      if (related[req.type] && related[req.type].includes(listing.type)) {
        matScore = 0.4;
      }
    }

    // 2. Quantity Compatibility (20%)
    let qtyScore = 0;
    if (listing.qty >= req.qty) {
      qtyScore = 1.0;
    } else {
      qtyScore = Math.max(0, listing.qty / req.qty);
    }

    // 3. Distance (20%)
    const dist = getDistance(req.location, listing.location);
    let distScore = 0;
    if (dist === 0) distScore = 1.0;
    else if (dist < 100) distScore = 0.9;
    else if (dist < 300) distScore = 0.7;
    else if (dist < 500) distScore = 0.5;
    else if (dist < 1000) distScore = 0.3;
    else distScore = 0.1;

    // 4. Condition (15%)
    let condScore = 0;
    const listingRank = conditionRank[listing.condition];
    const requiredRank = conditionRank[req.minCondition];
    if (listingRank >= requiredRank) {
      condScore = conditionScores[listing.condition];
    } else {
      condScore = conditionScores[listing.condition] * 0.3;
    }

    // 5. Availability (15%)
    let dateScore = 0;
    const reqDate = new Date(req.date);
    const listDate = new Date(listing.date);
    const daysDiff = (reqDate - listDate) / (1000 * 60 * 60 * 24);
    if (daysDiff >= 0) {
      dateScore = daysDiff < 7 ? 1.0 : daysDiff < 14 ? 0.8 : daysDiff < 30 ? 0.6 : 0.4;
    } else {
      // Listing available after required date
      const daysLate = Math.abs(daysDiff);
      dateScore = daysLate < 3 ? 0.7 : daysLate < 7 ? 0.4 : 0.1;
    }

    const totalScore = (matScore * 0.30 + qtyScore * 0.20 + distScore * 0.20 + condScore * 0.15 + dateScore * 0.15) * 100;

    // Build reasons
    const reasons = [];
    if (matScore === 1.0) reasons.push('Exact material match');
    else if (matScore > 0) reasons.push('Related material type');
    if (qtyScore === 1.0) reasons.push('Sufficient quantity');
    else if (qtyScore >= 0.7) reasons.push('Near-full quantity');
    if (distScore >= 0.9) reasons.push('Same city / Very close');
    else if (distScore >= 0.5) reasons.push('Moderate distance');
    if (condScore >= 0.8) reasons.push(`${listing.condition} condition`);
    if (dateScore >= 0.8) reasons.push('Available on time');

    // Cost calculations
    const transportCost = Math.round(dist * 15 * (listing.qty / 1000 || 1));
    const newCost = (newPrices[listing.type] || listing.price * 1.5) * (listing.qty / (listing.unit === 'tons' ? 1 : listing.unit === 'kg' ? 1000 : 1));
    const surplusCost = listing.price * listing.qty;
    const savings = Math.max(0, Math.round(newCost - surplusCost - transportCost));

    // CO₂ estimate
    const weightKg = listing.unit === 'tons' ? listing.qty * 1000 : listing.unit === 'kg' ? listing.qty : listing.qty * 2.5;
    const co2 = Math.round(weightKg * (co2Factors[listing.type] || 0.5));

    return {
      listing,
      score: Math.round(totalScore),
      breakdown: {
        material: Math.round(matScore * 30),
        quantity: Math.round(qtyScore * 20),
        distance: Math.round(distScore * 20),
        condition: Math.round(condScore * 15),
        availability: Math.round(dateScore * 15),
      },
      reasons,
      distanceKm: Math.round(dist),
      transportCost,
      surplusCost: Math.round(surplusCost),
      savings,
      co2,
    };
  });

  // Sort by score descending, return top 3
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3);
}

function getDistance(city1, city2) {
  if (city1 === city2) return 0;
  const c1 = cityCoords[city1];
  const c2 = cityCoords[city2];
  if (!c1 || !c2) return 500; // default

  const R = 6371;
  const dLat = (c2.lat - c1.lat) * Math.PI / 180;
  const dLng = (c2.lng - c1.lng) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(c1.lat * Math.PI / 180) * Math.cos(c2.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function renderMatchResults(matches, req) {
  const panel = document.getElementById('ai-results-panel');

  if (matches.length === 0 || matches[0].score < 5) {
    panel.innerHTML = `
      <div class="ai-placeholder">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>No Strong Matches Found</h3>
        <p>Try broadening your criteria — accepting a lower condition, extending your date, or searching nearby cities.</p>
      </div>
    `;
    return;
  }

  // Reuse Before Buy banner
  const topMatch = matches[0];
  const totalSavings = matches.reduce((sum, m) => sum + m.savings, 0);
  const totalCO2 = matches.reduce((sum, m) => sum + m.co2, 0);

  let html = `
    <div class="reuse-banner">
      <div class="reuse-banner-header">
        <i class="fas fa-lightbulb"></i> Reuse Before Buy — Recommendation
      </div>
      <p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:12px;">
        By choosing surplus materials instead of purchasing new, you could potentially:
      </p>
      <div class="reuse-stats">
        <div class="reuse-stat">
          <span class="value" style="color:var(--emerald)">₹${totalSavings.toLocaleString('en-IN')}</span>
          <span class="label">Est. Procurement Savings</span>
        </div>
        <div class="reuse-stat">
          <span class="value" style="color:var(--cyan)">${totalCO2.toLocaleString('en-IN')} kg</span>
          <span class="label">CO₂ Potentially Avoided</span>
        </div>
        <div class="reuse-stat">
          <span class="value" style="color:var(--purple)">${matches.length}</span>
          <span class="label">Matching Surplus Listings</span>
        </div>
      </div>
      <p style="font-size:0.72rem;color:var(--text-muted);margin-top:10px;font-style:italic;">
        <i class="fas fa-info-circle"></i> Estimates based on demo market prices and standard emission factors. Not real financial or environmental predictions.
      </p>
    </div>
  `;

  // Render match cards
  matches.forEach((match, i) => {
    const rank = i + 1;
    const l = match.listing;
    const circumference = 2 * Math.PI * 28;
    const dashOffset = circumference - (match.score / 100) * circumference;
    const scoreColor = match.score >= 70 ? 'var(--emerald)' : match.score >= 45 ? 'var(--amber)' : 'var(--rose)';

    html += `
      <div class="match-card match-rank-${rank}">
        <div class="match-header">
          <div class="match-rank">
            <div class="rank-badge rank-${rank}">#${rank}</div>
            <div>
              <div class="match-title">${l.type}</div>
              <div class="match-supplier">${l.supplier} · ${l.company}</div>
            </div>
          </div>
          <div class="match-score-circle">
            <svg viewBox="0 0 64 64">
              <circle class="bg" cx="32" cy="32" r="28" />
              <circle cx="32" cy="32" r="28" stroke="${scoreColor}" stroke-dasharray="${circumference}" stroke-dashoffset="${dashOffset}" stroke-linecap="round" />
            </svg>
            <span class="score-value" style="color:${scoreColor}">${match.score}</span>
            <span class="score-label">Score</span>
          </div>
        </div>

        <div class="match-details">
          <div class="match-detail"><i class="fas fa-cubes"></i> ${l.qty.toLocaleString('en-IN')} ${l.unit}</div>
          <div class="match-detail"><i class="fas fa-star"></i> ${l.condition} condition</div>
          <div class="match-detail"><i class="fas fa-location-dot"></i> ${l.location} (${match.distanceKm} km)</div>
          <div class="match-detail"><i class="fas fa-calendar"></i> ${formatDate(l.date)}</div>
        </div>

        <div class="score-breakdown">
          <div class="score-breakdown-title">Score Breakdown</div>
          <div class="score-bar-stack">
            <div class="score-segment" style="width:${match.breakdown.material}%;background:var(--emerald)"></div>
            <div class="score-segment" style="width:${match.breakdown.quantity}%;background:var(--blue)"></div>
            <div class="score-segment" style="width:${match.breakdown.distance}%;background:var(--amber)"></div>
            <div class="score-segment" style="width:${match.breakdown.condition}%;background:var(--purple)"></div>
            <div class="score-segment" style="width:${match.breakdown.availability}%;background:var(--rose)"></div>
          </div>
          <div class="score-labels">
            <div class="score-label-item"><span class="dot" style="background:var(--emerald)"></span> Material ${match.breakdown.material}/30</div>
            <div class="score-label-item"><span class="dot" style="background:var(--blue)"></span> Quantity ${match.breakdown.quantity}/20</div>
            <div class="score-label-item"><span class="dot" style="background:var(--amber)"></span> Distance ${match.breakdown.distance}/20</div>
            <div class="score-label-item"><span class="dot" style="background:var(--purple)"></span> Condition ${match.breakdown.condition}/15</div>
            <div class="score-label-item"><span class="dot" style="background:var(--rose)"></span> Availability ${match.breakdown.availability}/15</div>
          </div>
        </div>

        <div class="match-reasons">
          <h4>Match Reasons</h4>
          ${match.reasons.map(r => `<span class="reason-tag"><i class="fas fa-check"></i> ${r}</span>`).join('')}
        </div>

        <div class="cost-breakdown">
          <div class="cost-item">
            <div class="cost-value">₹${match.surplusCost.toLocaleString('en-IN')}</div>
            <div class="cost-label">Surplus Cost</div>
          </div>
          <div class="cost-item transport">
            <div class="cost-value">₹${match.transportCost.toLocaleString('en-IN')}</div>
            <div class="cost-label">Est. Transport</div>
          </div>
          <div class="cost-item savings">
            <div class="cost-value">₹${match.savings.toLocaleString('en-IN')}</div>
            <div class="cost-label">Est. Savings</div>
          </div>
        </div>

        <div class="match-actions">
          <button class="btn btn-primary btn-sm" onclick="openRequestModal(${l.id})"><i class="fas fa-paper-plane"></i> Send Request</button>
          <button class="btn btn-outline btn-sm" onclick="openDetailModal(${l.id})"><i class="fas fa-eye"></i> View Details</button>
        </div>
      </div>
    `;
  });

  panel.innerHTML = html;
}

// ============================================================
//  REQUESTS
// ============================================================

function renderRequests(filter = 'all') {
  const list = document.getElementById('requests-list');
  const descEl = document.getElementById('requests-desc');

  if (currentRole === 'buyer') {
    descEl.textContent = 'Track material requests you have sent.';
  } else if (currentRole === 'supplier') {
    descEl.textContent = 'Review and respond to incoming material requests.';
  } else {
    descEl.textContent = 'View all platform requests.';
  }

  const filtered = filter === 'all' ? requests : requests.filter(r => r.status === filter);

  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty-state-small"><i class="fas fa-inbox"></i><p>No requests to display.</p></div>';
    return;
  }

  list.innerHTML = filtered.map(r => {
    const iconColors = { pending: 'amber', accepted: 'emerald', declined: 'rose' };
    const iconNames = { pending: 'fas fa-clock', accepted: 'fas fa-check-circle', declined: 'fas fa-times-circle' };

    return `
      <div class="request-card">
        <div class="request-icon stat-icon ${iconColors[r.status]}">
          <i class="${iconNames[r.status]}"></i>
        </div>
        <div class="request-info">
          <h4>${r.materialType} — ${r.qty}</h4>
          <p>From: ${r.from} → To: ${r.to}</p>
        </div>
        <div class="request-meta">
          <span class="request-status status-${r.status}-badge">${r.status}</span>
          <div class="request-date">${formatDate(r.date)}</div>
        </div>
        ${currentRole === 'supplier' && r.status === 'pending' ? `
          <div class="request-actions">
            <button class="btn btn-success btn-sm" onclick="updateRequest(${r.id}, 'accepted')"><i class="fas fa-check"></i></button>
            <button class="btn btn-danger btn-sm" onclick="updateRequest(${r.id}, 'declined')"><i class="fas fa-times"></i></button>
          </div>
        ` : ''}
      </div>
    `;
  }).join('');
}

function switchRequestTab(tab, btnEl) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  if (btnEl) btnEl.classList.add('active');
  renderRequests(tab);
}

function updateRequest(id, status) {
  const req = requests.find(r => r.id === id);
  if (req) {
    req.status = status;
    renderRequests();
    showToast(`Request ${status}!`, status === 'accepted' ? 'success' : 'info');
  }
}

// ============================================================
//  MODALS
// ============================================================

function openRequestModal(listingId) {
  const listing = surplusListings.find(l => l.id === listingId);
  if (!listing) return;

  const modal = document.getElementById('request-modal');
  document.getElementById('modal-title').textContent = `Request: ${listing.type}`;
  document.getElementById('modal-body').innerHTML = `
    <div style="margin-bottom:20px;">
      <div class="listing-meta">
        <div class="listing-meta-item"><i class="fas fa-cubes"></i> Available: ${listing.qty.toLocaleString('en-IN')} ${listing.unit}</div>
        <div class="listing-meta-item"><i class="fas fa-location-dot"></i> ${listing.location}</div>
        <div class="listing-meta-item"><i class="fas fa-user"></i> ${listing.supplier}</div>
        <div class="listing-meta-item"><i class="fas fa-tag"></i> ₹${listing.price.toLocaleString('en-IN')} ${listing.priceUnit}</div>
      </div>
    </div>
    <div class="form-group" style="margin-bottom:16px;">
      <label>Requested Quantity</label>
      <div class="input-with-unit">
        <input type="number" id="req-qty" placeholder="e.g. 200" value="${Math.min(listing.qty, Math.round(listing.qty * 0.5))}" min="1" max="${listing.qty}" />
        <span style="padding:10px;color:var(--text-muted)">${listing.unit}</span>
      </div>
    </div>
    <div class="form-group" style="margin-bottom:16px;">
      <label>Message to Supplier</label>
      <textarea id="req-message" rows="3" placeholder="Hi, I'm interested in this material for my project…" style="background:var(--bg-elevated);border:1px solid var(--border-light);color:var(--text-primary);padding:10px;border-radius:var(--radius-md);font-family:inherit;font-size:0.88rem;width:100%;outline:none;resize:vertical;"></textarea>
    </div>
    <button class="btn btn-primary btn-block" onclick="submitRequest(${listing.id})">
      <i class="fas fa-paper-plane"></i> Send Request
    </button>
  `;

  modal.classList.add('active');
}

function openDetailModal(listingId) {
  const listing = surplusListings.find(l => l.id === listingId);
  if (!listing) return;

  const modal = document.getElementById('request-modal');
  document.getElementById('modal-title').textContent = listing.type;

  // Cost comparison
  const newPrice = newPrices[listing.type] || listing.price * 1.5;
  const savingsPercent = Math.round(((newPrice - listing.price) / newPrice) * 100);

  document.getElementById('modal-body').innerHTML = `
    <div style="margin-bottom:20px;">
      <div class="listing-meta" style="gap:10px;">
        <div class="listing-meta-item"><i class="fas fa-cubes"></i> <strong>${listing.qty.toLocaleString('en-IN')} ${listing.unit}</strong></div>
        <div class="listing-meta-item"><i class="fas fa-star"></i> ${listing.condition} condition</div>
        <div class="listing-meta-item"><i class="fas fa-location-dot"></i> ${listing.location}</div>
        <div class="listing-meta-item"><i class="fas fa-calendar"></i> Available: ${formatDate(listing.date)}</div>
        <div class="listing-meta-item"><i class="fas fa-user"></i> ${listing.supplier} — ${listing.company}</div>
      </div>
    </div>
    <div class="listing-price" style="font-size:1.4rem;margin-bottom:16px;">
      ₹${listing.price.toLocaleString('en-IN')} <small>${listing.priceUnit}</small>
    </div>
    ${listing.desc ? `<p style="font-size:0.88rem;color:var(--text-secondary);margin-bottom:16px;line-height:1.6;">${listing.desc}</p>` : ''}
    <div style="background:var(--bg-elevated);border-radius:var(--radius-md);padding:14px;margin-bottom:16px;">
      <div style="font-size:0.78rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.04em;margin-bottom:8px;">Price Comparison (Demo)</div>
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="font-size:0.82rem;color:var(--text-muted);">New Market Price</div>
          <div style="font-size:1rem;font-weight:700;text-decoration:line-through;color:var(--rose);">₹${newPrice.toLocaleString('en-IN')}</div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:0.82rem;color:var(--text-muted);">Surplus Price</div>
          <div style="font-size:1rem;font-weight:700;color:var(--emerald);">₹${listing.price.toLocaleString('en-IN')}</div>
        </div>
        <div style="text-align:center;padding:8px 14px;background:rgba(16,185,129,0.1);border-radius:var(--radius-md);">
          <div style="font-size:1.1rem;font-weight:800;color:var(--emerald);">${savingsPercent}%</div>
          <div style="font-size:0.68rem;color:var(--text-muted);">Savings</div>
        </div>
      </div>
    </div>
    ${currentRole === 'buyer' ? `
      <button class="btn btn-primary btn-block" onclick="closeModal(); openRequestModal(${listing.id});">
        <i class="fas fa-paper-plane"></i> Request This Material
      </button>
    ` : ''}
  `;

  modal.classList.add('active');
}

function submitRequest(listingId) {
  const listing = surplusListings.find(l => l.id === listingId);
  if (!listing) return;

  const qty = document.getElementById('req-qty').value;

  const newReq = {
    id: requests.length + 1,
    materialType: listing.type,
    qty: `${qty} ${listing.unit}`,
    from: currentRole === 'buyer' ? 'Priya Patel' : 'Demo User',
    to: listing.supplier,
    status: 'pending',
    date: new Date().toISOString().split('T')[0],
    listingId: listing.id,
  };

  requests.unshift(newReq);
  closeModal();
  showToast('Request sent successfully!', 'success');
}

function closeModal(e) {
  if (e && e.target !== e.currentTarget) return;
  document.getElementById('request-modal').classList.remove('active');
}

// ============================================================
//  ENVIRONMENTAL IMPACT DASHBOARD
// ============================================================

function renderImpactDashboard() {
  // Demo aggregated data
  const impactData = {
    materialReused: 2450, // tons
    costSavings: 18200000, // ₹
    wasteDiverted: 2450, // tons
    co2Avoided: 890, // tons
    waterSaved: 45600000, // litres
  };

  // Stats
  const statsEl = document.getElementById('impact-stats');
  statsEl.innerHTML = `
    <div class="impact-stat-card">
      <i class="fas fa-recycle"></i>
      <div class="impact-value">${impactData.materialReused.toLocaleString('en-IN')} T</div>
      <div class="impact-label">Materials Reused</div>
      <div class="impact-detail">Σ completed transaction weights</div>
    </div>
    <div class="impact-stat-card">
      <i class="fas fa-indian-rupee-sign"></i>
      <div class="impact-value">₹${(impactData.costSavings / 10000000).toFixed(1)} Cr</div>
      <div class="impact-label">Estimated Cost Savings</div>
      <div class="impact-detail">new_cost − surplus_cost − transport</div>
    </div>
    <div class="impact-stat-card">
      <i class="fas fa-trash-arrow-up"></i>
      <div class="impact-value">${impactData.wasteDiverted.toLocaleString('en-IN')} T</div>
      <div class="impact-label">Waste Diverted</div>
      <div class="impact-detail">Materials saved from landfill</div>
    </div>
    <div class="impact-stat-card">
      <i class="fas fa-cloud"></i>
      <div class="impact-value">${impactData.co2Avoided.toLocaleString('en-IN')} T</div>
      <div class="impact-label">CO₂ Avoided</div>
      <div class="impact-detail">weight × emission_factor</div>
    </div>
    <div class="impact-stat-card">
      <i class="fas fa-droplet"></i>
      <div class="impact-value">${(impactData.waterSaved / 1000000).toFixed(1)}M L</div>
      <div class="impact-label">Water Saved</div>
      <div class="impact-detail">weight × water_factor</div>
    </div>
  `;

  // Bar chart: Materials by category
  renderBarChart();

  // Pie chart: Cost savings breakdown
  renderPieChart();

  // Trend chart
  renderTrendChart();
}

function renderBarChart() {
  const container = document.getElementById('chart-materials');
  const data = [
    { label: 'Steel', value: 680, color: 'var(--emerald)' },
    { label: 'Cement', value: 520, color: 'var(--blue)' },
    { label: 'Bricks', value: 440, color: 'var(--amber)' },
    { label: 'AAC', value: 310, color: 'var(--purple)' },
    { label: 'Plywood', value: 180, color: 'var(--cyan)' },
    { label: 'Sand', value: 200, color: 'var(--rose)' },
    { label: 'Other', value: 120, color: 'var(--indigo)' },
  ];

  const maxVal = Math.max(...data.map(d => d.value));

  container.innerHTML = `
    <div class="bar-chart">
      ${data.map(d => {
    const height = (d.value / maxVal) * 170;
    return `
          <div class="bar-col">
            <div class="bar" style="height:${height}px;background:${d.color};">
              <span class="bar-value" style="color:${d.color}">${d.value}T</span>
            </div>
            <span class="bar-label">${d.label}</span>
          </div>
        `;
  }).join('')}
    </div>
  `;
}

function renderPieChart() {
  const container = document.getElementById('chart-savings');
  const data = [
    { label: 'Material Cost Savings', value: 65, color: 'var(--emerald)' },
    { label: 'Transport Avoided', value: 15, color: 'var(--blue)' },
    { label: 'Labour Savings', value: 12, color: 'var(--purple)' },
    { label: 'Disposal Cost Avoided', value: 8, color: 'var(--amber)' },
  ];

  let gradient = '';
  let cumulative = 0;
  data.forEach(d => {
    const start = cumulative * 3.6;
    cumulative += d.value;
    const end = cumulative * 3.6;
    gradient += `${d.color} ${start}deg ${end}deg, `;
  });
  gradient = gradient.slice(0, -2);

  container.innerHTML = `
    <div class="pie-chart-container">
      <div class="pie-chart" style="background:conic-gradient(${gradient})"></div>
      <div class="pie-legend">
        ${data.map(d => `
          <div class="pie-legend-item">
            <span class="pie-legend-dot" style="background:${d.color}"></span>
            ${d.label} (${d.value}%)
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderTrendChart() {
  const container = document.getElementById('chart-trend');
  const months = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'];
  const values = [120, 210, 280, 350, 410, 490];
  const maxVal = Math.max(...values);
  const width = 100;
  const height = 200;
  const padding = 30;

  const points = values.map((v, i) => {
    const x = padding + (i / (values.length - 1)) * (width - 2 * padding);
    const y = height - padding - ((v / maxVal) * (height - 2 * padding));
    return { x: x * 4, y, val: v };
  });

  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaD = pathD + ` L ${points[points.length - 1].x} ${height - padding} L ${points[0].x} ${height - padding} Z`;

  container.innerHTML = `
    <div class="line-chart-container">
      <svg viewBox="0 0 ${width * 4} ${height + 20}">
        <!-- Grid lines -->
        ${[0, 0.25, 0.5, 0.75, 1].map(pct => {
    const y = height - padding - pct * (height - 2 * padding);
    return `<line x1="${padding * 4}" y1="${y}" x2="${(width - padding) * 4}" y2="${y}" stroke="rgba(255,255,255,0.05)" stroke-width="1" />`;
  }).join('')}

        <!-- Area -->
        <path d="${areaD}" fill="url(#areaGrad)" opacity="0.3" />

        <!-- Line -->
        <path d="${pathD}" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />

        <!-- Dots -->
        ${points.map((p, i) => `
          <circle cx="${p.x}" cy="${p.y}" r="4" fill="#10b981" stroke="#0a0f1a" stroke-width="2" />
          <text x="${p.x}" y="${p.y - 12}" fill="#94a3b8" font-size="10" text-anchor="middle">${p.val}T</text>
          <text x="${p.x}" y="${height + 5}" fill="#64748b" font-size="10" text-anchor="middle">${months[i]}</text>
        `).join('')}

        <defs>
          <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#10b981" />
            <stop offset="100%" stop-color="#10b981" stop-opacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
    <p style="text-align:center;font-size:0.72rem;color:var(--text-muted);margin-top:8px;">
      Monthly materials reused (tons) — Demo trend data, Apr–Sep 2026
    </p>
  `;
}

// ============================================================
//  ADMIN DASHBOARD
// ============================================================

function renderAdminDashboard() {
  const statsEl = document.getElementById('admin-stats');
  statsEl.innerHTML = `
    ${statCard('fas fa-users', 'emerald', 'Total Users', '247', '↑ 18 new this week')}
    ${statCard('fas fa-warehouse', 'blue', 'Suppliers', '98', '40% of users')}
    ${statCard('fas fa-cart-shopping', 'purple', 'Buyers', '134', '54% of users')}
    ${statCard('fas fa-boxes-stacked', 'amber', 'Active Listings', surplusListings.length, `${surplusListings.length} materials`)}
    ${statCard('fas fa-handshake', 'cyan', 'Transactions', '340', '₹18.2 Cr total')}
    ${statCard('fas fa-flag', 'rose', 'Flagged', '0', 'All clear')}
  `;
}

// ============================================================
//  TOAST NOTIFICATIONS
// ============================================================

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const icons = { success: 'fas fa-check-circle', error: 'fas fa-exclamation-circle', info: 'fas fa-info-circle' };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<i class="${icons[type]}"></i> ${message}`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    toast.style.transition = 'all 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ============================================================
//  UTILITIES
// ============================================================

function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ============================================================
//  HERO COUNTER ANIMATION
// ============================================================

function animateCounters() {
  const counters = document.querySelectorAll('.stat-number[data-target]');
  counters.forEach(counter => {
    const target = parseInt(counter.dataset.target);
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      counter.textContent = Math.round(current).toLocaleString('en-IN');
    }, 16);
  });
}

// ============================================================
//  INITIALIZATION
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  // Set today's date as default for date inputs
  const today = new Date().toISOString().split('T')[0];
  const dateInputs = document.querySelectorAll('input[type="date"]');
  dateInputs.forEach(input => {
    if (!input.value) input.value = today;
  });

  // Build sidebar navigation
  buildSidebarNav();
  switchRole('buyer');

  // Animate landing page counters
  setTimeout(animateCounters, 500);

  // Set default date for AI matching to 2 weeks from now
  const twoWeeks = new Date();
  twoWeeks.setDate(twoWeeks.getDate() + 14);
  const aiDate = document.getElementById('ai-date');
  if (aiDate) aiDate.value = twoWeeks.toISOString().split('T')[0];
});

// Keyboard shortcut: Escape closes modal
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});
