# Intelligent Land Record Digitization & Validation System
### Smart India Hackathon (SIH) Working Prototype

An automated, local web prototype for digitizing scanned cadastral/land-record documents (e.g. Maharashtra 7/12 extracts, Jamabandi, Record of Rights), extracting structured land ownership attributes, and detecting fraud, syntax errors, and cross-record ownership/area conflicts.

---

## 🚀 Quick Start Instructions

### 1. Requirements
Ensure Python 3.10+ is installed. The dependencies are specified in `requirements.txt`:
```bash
pip install -r requirements.txt
```

### 2. Run Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 3. Load SIH Demo Data
Pre-populates sample land records showing both consistent registrations and active conflict detection:
```bash
python manage.py seed_samples
```

### 4. Start the Local Server
```bash
python manage.py runserver
```
Visit **[http://127.0.0.1:8000](http://127.0.0.1:8000)** in your browser.

---

## 🧠 The Three Core Algorithms

The core logic is modularly organized in dedicated Python files:

| Algorithm | File Path | Primary Function & Description |
|---|---|---|
| **1. Tesseract OCR (LSTM)** | [`land_records/ocr.py`](file:///c:/ai%20project/land_records/ocr.py) | OpenCV document image preprocessing (Grayscale conversion, Gaussian noise filtering, Otsu's adaptive thresholding binarization) followed by Tesseract OCR character recognition with an auto-resilient fallback engine for offline environments. |
| **2. Information Extraction / NER** | [`land_records/extraction.py`](file:///c:/ai%20project/land_records/extraction.py) | High-precision regex and linguistic rule-based entity extraction for: **Owner Name**, **Survey / Gat Number**, **Area (float + unit)**, **Village**, **Taluka**, **District**, and **Record Date**. |
| **3. Rule-Based Anomaly Detection** | [`land_records/validation.py`](file:///c:/ai%20project/land_records/validation.py) | Cadastral integrity validator enforcing positive area values, survey number formatting, pure-Python Levenshtein string similarity (for OCR typo tolerance vs genuine different owners), and cross-record duplicate/conflict detection. |

---

## 🚦 Status Classification
- 🟢 **Consistent**: Passed all syntax, structural, and cross-record database integrity validations.
- 🟡 **Requires Verification**: Minor warnings (e.g. potential OCR typo or missing secondary non-mandatory fields).
- 🔴 **Anomaly Detected**: Hard conflict detected (e.g. same Survey Number claiming different owners, mismatched parcel area, non-positive area, or invalid survey format).

---

## 🎯 How to Demonstrate to SIH Judges

1. **Dashboard Overview (`/`)**:
   - Show the 4 live metric cards: Total Records, Consistent, Requires Verification, and Anomalies.
   - Explain the 5-stage pipeline diagram displayed on the dashboard.
2. **Review Existing Sample Records (`/records/`)**:
   - Point out **Survey 101/1** (Rajesh Patil) and **Survey 102/2** (Amit Sharma) showing 🟢 **Consistent**.
   - Point out **Survey 125/2** (Rajesh Patil, 2.5 ha) and **Survey 125/2** (Amit Sharma, 3.7 ha) showing 🔴 **Anomaly Detected**.
3. **Inspect the Conflict Detail (`/records/<id>/`)**:
   - Open Record for Survey `125/2`.
   - Show the **Red Anomaly Alert Box** stating the exact reason:
     *“Same Survey Number has conflicting owner and area information.”*
   - Show the **Conflicting Database Records Detected** table comparing both records side-by-side.
   - Toggle between **Original Document** and **Preprocessed (OpenCV)** views.
   - Show the **Tesseract OCR (LSTM) Text Output** box and structured extracted attributes.
4. **Live Document Upload (`/upload/`)**:
   - Click *“Option B: Instant Hackathon Demo Scenarios”* or upload a PNG/JPG/PDF.
   - Watch the pipeline execute OCR → Entity Extraction → Cross-Database Collision Check → Redirect to detailed diagnostic report in real time!

---

## 🧪 Automated Testing
Run the test suite covering all three algorithms and HTTP views:
```bash
python manage.py test
```
Result: `9 tests passed (100% OK)`.
