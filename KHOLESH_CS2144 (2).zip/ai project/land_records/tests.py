from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from land_records.models import LandRecord
from land_records.ocr import run_tesseract_ocr
from land_records.extraction import extract_land_record_entities
from land_records.validation import validate_land_record, levenshtein_similarity, is_valid_survey_number


class LandRecordAlgorithmTests(TestCase):
    def test_levenshtein_similarity(self):
        # Identical strings
        self.assertEqual(levenshtein_similarity("Rajesh Patil", "Rajesh Patil"), 1.0)
        # Minor OCR typo
        sim_typo = levenshtein_similarity("Rajesh Patil", "Rajesh Paatil")
        self.assertGreater(sim_typo, 0.85)
        # Completely different owner
        sim_diff = levenshtein_similarity("Rajesh Patil", "Amit Sharma")
        self.assertLess(sim_diff, 0.5)

    def test_survey_format_validation(self):
        self.assertTrue(is_valid_survey_number("101/1"))
        self.assertTrue(is_valid_survey_number("125/2"))
        self.assertTrue(is_valid_survey_number("45-A"))
        self.assertTrue(is_valid_survey_number("200"))
        self.assertFalse(is_valid_survey_number("??INVALID$$"))
        self.assertFalse(is_valid_survey_number(""))

    def test_entity_extraction(self):
        sample_text = (
            "GOVERNMENT REVENUE RECORD\n"
            "District: Pune\n"
            "Taluka: Haveli\n"
            "Village: Pune\n"
            "Survey / Gat Number: 101/1\n"
            "Owner / Occupant Name: Rajesh Patil\n"
            "Total Land Area: 2.5 Hectares\n"
            "Date of Record: 12/04/2023"
        )
        entities = extract_land_record_entities(sample_text)
        self.assertEqual(entities['survey_number'], "101/1")
        self.assertEqual(entities['owner_name'], "Rajesh Patil")
        self.assertEqual(entities['area'], 2.5)
        self.assertEqual(entities['village'], "Pune")
        self.assertEqual(entities['taluka'], "Haveli")
        self.assertEqual(entities['district'], "Pune")

    def test_rule_based_anomaly_detection_conflict(self):
        # Existing record in database
        rec1 = LandRecord.objects.create(
            survey_number="125/2",
            owner_name="Rajesh Patil",
            area=2.5,
            village="Pune",
            status="consistent"
        )

        # Uploading conflicting record with same survey number but different owner and area
        candidate_data = {
            'survey_number': "125/2",
            'owner_name': "Amit Sharma",
            'area': 3.7,
            'village': "Pune",
            'id': None
        }

        status, reasons, conflicts = validate_land_record(
            candidate_data,
            existing_records=[rec1]
        )

        self.assertEqual(status, 'anomaly')
        self.assertTrue(any("conflicting owner" in r.lower() for r in reasons))
        self.assertTrue(any("area mismatch" in r.lower() or "conflicting area" in r.lower() for r in reasons))
        self.assertGreater(len(conflicts), 0)

    def test_rule_based_anomaly_detection_invalid_area(self):
        candidate_data = {
            'survey_number': "105/1",
            'owner_name': "Suresh Kulkarni",
            'area': -1.5,
            'village': "Pune"
        }
        status, reasons, _ = validate_land_record(candidate_data)
        self.assertEqual(status, 'anomaly')
        self.assertTrue(any("greater than 0" in r.lower() for r in reasons))


class LandRecordViewsTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.rec1 = LandRecord.objects.create(
            survey_number="101/1",
            owner_name="Rajesh Patil",
            area=2.5,
            village="Pune",
            status="consistent",
            ocr_raw_text="Test OCR content"
        )

    def test_unauthenticated_redirect(self):
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response.url)

    def test_login_and_access_dashboard(self):
        login_res = self.client.post(reverse('login'), {
            'username': 'testuser',
            'password': 'password123'
        })
        self.assertEqual(login_res.status_code, 302)

        dashboard_res = self.client.get(reverse('dashboard'))
        self.assertEqual(dashboard_res.status_code, 200)
        self.assertContains(dashboard_res, "Dashboard")
        self.assertContains(dashboard_res, "101/1")

    def test_record_list_view(self):
        self.client.login(username='testuser', password='password123')
        response = self.client.get(reverse('record_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Rajesh Patil")

    def test_record_detail_view(self):
        self.client.login(username='testuser', password='password123')
        response = self.client.get(reverse('record_detail', args=[self.rec1.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "101/1")
        self.assertContains(response, "Test OCR content")

    def test_upload_sample_post(self):
        self.client.login(username='testuser', password='password123')
        response = self.client.post(reverse('upload_record'), {
            'sample_choice': 'sample_1'
        })
        # Should redirect to the newly created record's detail page
        self.assertEqual(response.status_code, 302)
        new_rec = LandRecord.objects.exclude(id=self.rec1.id).first()
        self.assertIsNotNone(new_rec)
        self.assertEqual(new_rec.survey_number, "101/1")

